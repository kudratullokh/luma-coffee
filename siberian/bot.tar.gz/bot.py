# -*- coding: utf-8 -*-
"""Siberian Wellness консультанти учун Telegram бот.

Созлаш ва ишга тушириш: README.md
Матнлар: texts.py   Маҳсулотлар: products.json   Созламалар: .env
"""
from __future__ import annotations

import asyncio
import html
import io
import json
import logging
import os
import re
import sys
import tarfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from urllib.parse import urlencode

BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))  # texts.py ва storage.py шу папкадан олинади

from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ChatMemberStatus, ChatType, ParseMode
from aiogram.exceptions import (TelegramBadRequest, TelegramConflictError, TelegramForbiddenError,
                                TelegramRetryAfter)
from aiogram.filters import Command, CommandObject, CommandStart, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    BotCommand,
    BotCommandScopeAllPrivateChats,
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    Message,
    ReplyKeyboardMarkup,
    User,
    WebAppInfo,
)

import texts as T  # noqa: E402
from storage import TASHKENT, Storage  # noqa: E402

PRODUCTS_PATH = BASE_DIR / "products.json"
SOURCE_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")  # t.me/бот?start=<манба>
PHONE_RE = re.compile(r"^\+?[\d\s()-]{7,20}$")
# Етказиб бериш: (бепул бўладиган сумма, акс ҳолда нархи), сўм
DELIVERY_RULES = {"tashkent": (300_000, 20_000), "region": (700_000, 30_000)}
CHAT_CATEGORY_LIMIT = 8  # чатда бир бўлимдан нечта маҳсулот кўрсатилади
PRIVATE = F.chat.type == ChatType.PRIVATE

log = logging.getLogger("siberian_bot")


# --- Созламалар ------------------------------------------------------------

@dataclass
class Config:
    bot_token: str
    managers_chat_id: int
    consultant_name: str
    work_hours: str
    client_ref_link: str
    business_ref_link: str
    app_store_url: str
    google_play_url: str
    enable_orders: bool
    db_path: str
    setup_code: str = ""  # менежерлар группасида «/setgroup КОД» учун
    env_path: str = str(BASE_DIR / ".env")
    miniapp_url: str = ""  # мини-апп (каталог) манзили, https://...
    catalog_version: str = ""  # каталог янгиланганда Telegram эски саҳифани кўрсатмаслиги учун
    auto_update: bool = True  # бот кодини каталог сайтидаги bot.tar.gz дан ўзи янгилайди


def save_env_value(path: str, key: str, value: str) -> None:
    """.env файлидаги битта қийматни янгилайди (бот қайта ёқилганда ҳам эсда қолсин)."""
    env = Path(path)
    try:
        lines = env.read_text(encoding="utf-8").splitlines() if env.exists() else []
        for i, line in enumerate(lines):
            if line.split("=", 1)[0].strip() == key:
                lines[i] = f"{key}={value}"
                break
        else:
            lines.append(f"{key}={value}")
        env.write_text("\n".join(lines) + "\n", encoding="utf-8")
    except OSError as exc:
        log.warning(".env га ёзиб бўлмади: %s", exc)


def load_env(path: Path) -> None:
    """.env файлидаги KEY=VALUE қаторларини ўқийди. Бўш қиймат «кўрсатилмаган» деб ҳисобланади."""
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key, value = key.strip(), value.strip().strip('"').strip("'")
        if value and not os.environ.get(key):
            os.environ[key] = value


def load_config() -> Config:
    load_env(BASE_DIR / ".env")
    load_env(BASE_DIR / "defaults.env")  # .env да бўш қолган қийматлар учун (масалан, ҳомий ҳаволалари)
    env = os.environ.get
    return Config(
        bot_token=env("BOT_TOKEN", ""),
        managers_chat_id=int(env("MANAGERS_CHAT_ID", "0") or 0),
        consultant_name=env("CONSULTANT_NAME", ""),
        work_hours=env("WORK_HOURS", "иш вақтида"),
        client_ref_link=env("CLIENT_REF_LINK", ""),
        business_ref_link=env("BUSINESS_REF_LINK", ""),
        app_store_url=env("APP_STORE_URL", "https://apps.apple.com/app/id1095272878"),
        google_play_url=env("GOOGLE_PLAY_URL", ""),
        enable_orders=env("ENABLE_ORDERS", "1") == "1",
        db_path=env("DB_PATH", "") or str(BASE_DIR / "bot.db"),
        setup_code=env("SETUP_CODE", ""),
        miniapp_url=env("MINIAPP_URL", ""),
        catalog_version=env("CATALOG_VERSION", ""),
        auto_update=env("AUTO_UPDATE", "1") == "1",
    )


def load_products(path: Path = PRODUCTS_PATH) -> dict[str, list[dict]]:
    """products.json ни ўқийди: {"products": [...]} ёки эски {"health": [...], ...} шакли."""
    grouped: dict[str, list[dict]] = {key: [] for key in T.CATEGORIES}
    if not path.exists():
        return grouped
    data = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(data.get("products"), list):
        for item in data["products"]:
            grouped.setdefault(item.get("category", "other"), []).append(item)
        return grouped
    for key in grouped:
        grouped[key] = list(data.get(key, []))
    return grouped


def money(value) -> str:
    """504000 → «504 000». Рақам бўлмаса, ўзини қайтаради."""
    try:
        return f"{int(round(float(value))):,}".replace(",", " ")
    except (TypeError, ValueError):
        return str(value)


def points_text(value) -> str:
    try:
        number = round(float(value), 1)
    except (TypeError, ValueError):
        return str(value)
    return (str(int(number)) if number.is_integer() else str(number)).replace(".", ",")


def stats_text(db: Storage) -> str:
    """Ботга нечта одам кирди: умумий, бугун, 7 кунда ва манба (Instagram пости, QR ...) бўйича."""
    started = datetime.fromisoformat(db.started_at()).astimezone(TASHKENT).strftime("%d.%m.%Y %H:%M")
    since = T.STATS_SINCE.format(since=started)
    totals = db.totals()
    if not totals["users"]:
        return f"{T.STATS_EMPTY}\n{since}"
    lines = [
        T.STATS_LINE.format(
            source=html.escape(row["source"] or T.SOURCE_DIRECT),
            users=row["users"],
            registered=row["registered"] or 0,
            orders=row["orders"] or 0,
            business=row["business"] or 0,
            questions=row["questions"] or 0,
        )
        for row in db.stats()
    ]
    return f"{T.STATS_TOTAL.format(**totals)}\n{since}\n\n<b>{T.STATS_TITLE}</b>\n" + "\n".join(lines)


def has_webapp(cfg: "Config") -> bool:
    """Telegram мини-аппни фақат https:// манзилда очади."""
    return cfg.miniapp_url.startswith("https://")


def catalog_url(cfg: "Config") -> str:
    """Мини-апп манзили: версия (эски саҳифа кешдан чиқмасин) ва «Рўйхатдан ўтиш» учун реферал ҳавола қўшилади."""
    query = {key: value for key, value in (("v", cfg.catalog_version), ("ref", cfg.client_ref_link)) if value}
    if not query:
        return cfg.miniapp_url
    joiner = "&" if "?" in cfg.miniapp_url else "?"
    return f"{cfg.miniapp_url}{joiner}{urlencode(query)}"


# --- Ҳолатлар (бот жавоб кутаётган қадамлар) -----------------------------

class Reg(StatesGroup):
    phone = State()


class Ask(StatesGroup):
    question = State()


class BizTalk(StatesGroup):
    details = State()


class Order(StatesGroup):
    items = State()
    phone = State()
    address = State()
    payment = State()


# --- Клавиатуралар ---------------------------------------------------------

def main_menu(cfg: Config) -> ReplyKeyboardMarkup:
    first = (KeyboardButton(text=T.BTN_CATALOG, web_app=WebAppInfo(url=catalog_url(cfg))) if has_webapp(cfg)
             else KeyboardButton(text=T.BTN_PRODUCTS))
    rows = [[first, KeyboardButton(text=T.BTN_DISCOUNT)]]
    if cfg.enable_orders:
        rows.append([KeyboardButton(text=T.BTN_ORDER), KeyboardButton(text=T.BTN_DELIVERY)])
    else:
        rows.append([KeyboardButton(text=T.BTN_DELIVERY)])
    rows.append([KeyboardButton(text=T.BTN_BUSINESS), KeyboardButton(text=T.BTN_CONSULTANT)])
    return ReplyKeyboardMarkup(keyboard=rows, resize_keyboard=True)


def phone_keyboard(allow_skip: bool) -> ReplyKeyboardMarkup:
    rows = [[KeyboardButton(text=T.BTN_SEND_PHONE, request_contact=True)]]
    if allow_skip:
        rows.append([KeyboardButton(text=T.BTN_SKIP)])
    return ReplyKeyboardMarkup(keyboard=rows, resize_keyboard=True, one_time_keyboard=True)


def url_button(text: str, url: str) -> list[InlineKeyboardButton]:
    return [InlineKeyboardButton(text=text, url=url)] if url else []


def cb_button(text: str, data: str) -> list[InlineKeyboardButton]:
    return [InlineKeyboardButton(text=text, callback_data=data)]


def inline(*rows: list[InlineKeyboardButton]) -> InlineKeyboardMarkup | None:
    rows = [row for row in rows if row]
    return InlineKeyboardMarkup(inline_keyboard=list(rows)) if rows else None


# --- Ёрдамчи функциялар ----------------------------------------------------

def find_product(products: dict, product_id: str) -> dict | None:
    for items in products.values():
        for item in items:
            if str(item.get("id", "")) == product_id:
                return item
    return None


def remember(db: Storage, user: User, source: str | None = None) -> None:
    db.touch_user(user.id, user.full_name, user.username, source)


def describe_user(db: Storage, user: User) -> str:
    row = db.get_user(user.id)
    phone = row["phone"] if row and row["phone"] else "—"
    source = row["source"] if row and row["source"] else T.SOURCE_DIRECT
    return T.USER_LINE.format(
        user_id=user.id,
        name=html.escape(user.full_name),
        username=f"@{user.username}" if user.username else "",
        phone=html.escape(phone),
        source=html.escape(source),
    )


async def notify_managers(bot: Bot, cfg: Config, db: Storage, user_id: int, text: str) -> None:
    """Менежерлар группасига хабар. Унга Reply қилинса, жавоб мижозга боради."""
    if not cfg.managers_chat_id:
        log.warning("MANAGERS_CHAT_ID кўрсатилмаган — хабар группага юборилмади")
        return
    try:
        sent = await bot.send_message(cfg.managers_chat_id, f"{text}\n\n<i>{T.GROUP_REPLY_HINT}</i>")
    except (TelegramBadRequest, TelegramForbiddenError) as exc:
        log.error("Группага юбориб бўлмади (MANAGERS_CHAT_ID тўғрими, бот группадами?): %s", exc)
        return
    db.save_relay(sent.message_id, user_id)


async def drop_buttons(call: CallbackQuery) -> None:
    """Босилган inline тугмаларни олиб ташлайди (қайта босилмасин)."""
    if isinstance(call.message, Message):
        try:
            await call.message.edit_reply_markup(reply_markup=None)
        except TelegramBadRequest:
            pass


# --- Бот мантиғи -----------------------------------------------------------

def build_router(cfg: Config) -> Router:
    router = Router()
    hours = html.escape(cfg.work_hours)

    def managers(message: Message) -> bool:
        # /setgroup билан ишлаб турганда ўзгариши мумкин, шунинг учун ҳар сафар текширилади
        return bool(cfg.managers_chat_id) and message.chat.id == cfg.managers_chat_id

    async def send_discount(bot: Bot, chat_id: int) -> None:
        if cfg.client_ref_link:
            text = f"{T.DISCOUNT_INFO}\n\n{T.DISCOUNT_STEPS}"
            keyboard = inline(
                url_button(T.BTN_REGISTER, cfg.client_ref_link),
                cb_button(T.BTN_REGISTERED, "registered"),
            )
        else:
            log.warning("CLIENT_REF_LINK кўрсатилмаган")
            text, keyboard = f"{T.DISCOUNT_INFO}\n\n{T.REF_LINK_MISSING}", None
        await bot.send_message(chat_id, text, reply_markup=keyboard)

    async def start_order(bot: Bot, chat_id: int, state: FSMContext) -> None:
        await state.clear()
        await state.set_state(Order.items)
        await bot.send_message(chat_id, T.ORDER_ASK_ITEMS, reply_markup=main_menu(cfg))

    async def finish_registration(bot: Bot, user: User, state: FSMContext, db: Storage) -> None:
        data = await state.get_data()
        await state.clear()
        if data.get("first_time"):
            db.add_lead(user.id, "register")
            await notify_managers(bot, cfg, db, user.id,
                                  T.GROUP_REGISTERED.format(user=describe_user(db, user)))
        await bot.send_message(user.id, T.THANKS_MENU, reply_markup=main_menu(cfg))
        await bot.send_message(user.id, T.ASK_REMINDERS,
                               reply_markup=inline(cb_button(T.BTN_YES, "rem:1") + cb_button(T.BTN_NO, "rem:0")))

    async def relay_question(message: Message, bot: Bot, db: Storage, product: str | None) -> None:
        user = message.from_user
        remember(db, user)
        db.add_lead(user.id, "question", (message.text or message.caption or "")[:1000])
        header = T.GROUP_QUESTION.format(user=describe_user(db, user))
        if product:
            header += "\n" + T.GROUP_ABOUT_PRODUCT.format(product=html.escape(product))
        await notify_managers(bot, cfg, db, user.id, header)
        if cfg.managers_chat_id:
            try:
                copied = await bot.copy_message(cfg.managers_chat_id, message.chat.id, message.message_id)
                db.save_relay(copied.message_id, user.id)
            except (TelegramBadRequest, TelegramForbiddenError) as exc:
                log.error("Саволни группага нусхалаб бўлмади: %s", exc)
        await message.answer(T.QUESTION_SENT, reply_markup=main_menu(cfg))

    def reminder_keyboard() -> InlineKeyboardMarkup | None:
        return inline(
            cb_button(T.BTN_ORDER, "order") if cfg.enable_orders else [],
            cb_button(T.BTN_CONSULTANT, "consult"),
        )

    # 1. /start — Instagram/QR ҳаволасидаги манба билан
    @router.message(CommandStart(), PRIVATE)
    async def start(message: Message, command: CommandObject, state: FSMContext, db: Storage):
        await state.clear()
        source = command.args if command.args and SOURCE_RE.match(command.args) else None
        remember(db, message.from_user, source)
        welcome = (T.WELCOME.format(name=html.escape(cfg.consultant_name)) if cfg.consultant_name
                   else T.WELCOME_ANON)
        await message.answer(welcome, reply_markup=main_menu(cfg))

    # 2. /id — чат рақамини билиш (менежерлар группасини созлаш учун)
    @router.message(Command("id"))
    async def chat_id(message: Message):
        await message.reply(T.CHAT_ID.format(chat_id=message.chat.id))

    # 2а. /setgroup КОД — шу группани менежерлар группаси қилади (КОД .env даги SETUP_CODE)
    @router.message(Command("setgroup"))
    async def set_group(message: Message, command: CommandObject):
        if message.chat.type == ChatType.PRIVATE:
            await message.reply(T.SETGROUP_PRIVATE)
            return
        if not cfg.setup_code or (command.args or "").strip() != cfg.setup_code:
            await message.reply(T.SETGROUP_WRONG)
            return
        cfg.managers_chat_id = message.chat.id
        save_env_value(cfg.env_path, "MANAGERS_CHAT_ID", str(message.chat.id))
        log.info("Менежерлар группаси белгиланди: %s", message.chat.id)
        await message.reply(T.SETGROUP_DONE)

    # 3. Статистика: менежерлар группасида, группа аъзосига шахсий чатда ёки «/stats КОД» билан
    async def can_see_stats(message: Message, command: CommandObject, bot: Bot) -> bool:
        if message.chat.type != ChatType.PRIVATE:
            return managers(message)
        if cfg.setup_code and (command.args or "").strip() == cfg.setup_code:
            return True
        if not cfg.managers_chat_id:
            return False
        try:
            member = await bot.get_chat_member(cfg.managers_chat_id, message.from_user.id)
        except (TelegramBadRequest, TelegramForbiddenError):
            return False
        return member.status in (ChatMemberStatus.CREATOR, ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.MEMBER)

    @router.message(Command("stats"))
    async def stats(message: Message, command: CommandObject, bot: Bot, db: Storage):
        if not await can_see_stats(message, command, bot):
            if message.chat.type == ChatType.PRIVATE:
                await message.answer(T.STATS_PRIVATE_HINT)
            return
        await message.answer(stats_text(db))

    @router.message(Command("eslatma"), managers)
    async def send_reminders(message: Message, bot: Bot, db: Storage):
        recipients = db.reminder_recipients()
        sent = 0
        for user_id in recipients:
            for _attempt in range(2):
                try:
                    await bot.send_message(user_id, T.REMINDER, reply_markup=reminder_keyboard())
                    sent += 1
                    break
                except TelegramRetryAfter as exc:
                    await asyncio.sleep(exc.retry_after)
                except TelegramForbiddenError:
                    db.set_reminders(user_id, False)  # ботни блоклаган
                    break
                except TelegramBadRequest as exc:
                    log.warning("Эслатма юборилмади (%s): %s", user_id, exc)
                    break
            await asyncio.sleep(0.05)
        await message.reply(T.REMINDERS_SENT.format(sent=sent, total=len(recipients)))

    @router.message(Command("reload"), managers)
    async def reload_products(message: Message, products: dict):
        try:
            fresh = load_products()
        except (json.JSONDecodeError, OSError) as exc:
            await message.reply(T.PRODUCTS_ERROR.format(error=html.escape(str(exc))))
            return
        products.clear()
        products.update(fresh)
        await message.reply(T.PRODUCTS_RELOADED.format(count=sum(len(v) for v in fresh.values())))

    # 4. Менежер жавоби: группадаги бот хабарига Reply → мижозга боради
    @router.message(managers, F.reply_to_message)
    async def manager_reply(message: Message, bot: Bot, db: Storage):
        user_id = db.relay_user(message.reply_to_message.message_id)
        if user_id is None:
            return
        try:
            await bot.copy_message(user_id, message.chat.id, message.message_id)
        except TelegramForbiddenError:
            await message.reply(T.GROUP_USER_BLOCKED)
            return
        await message.reply(T.GROUP_REPLY_SENT)

    # 5. Асосий меню тугмалари — ҳар қандай қадамда ишлайди
    @router.message(PRIVATE, F.text == T.BTN_PRODUCTS)
    async def menu_products(message: Message, state: FSMContext):
        await state.clear()
        await message.answer(T.CHOOSE_CATEGORY, reply_markup=inline(
            *[cb_button(title, f"cat:{key}") for key, title in T.CATEGORIES.items()]))

    @router.message(PRIVATE, F.text == T.BTN_DISCOUNT)
    async def menu_discount(message: Message, state: FSMContext, bot: Bot):
        await state.clear()
        await send_discount(bot, message.chat.id)

    @router.message(PRIVATE, F.text == T.BTN_DELIVERY)
    async def menu_delivery(message: Message, state: FSMContext):
        await state.clear()
        await message.answer(T.DELIVERY)

    @router.message(PRIVATE, F.text == T.BTN_BUSINESS)
    async def menu_business(message: Message, state: FSMContext):
        await state.clear()
        await message.answer(T.BUSINESS, reply_markup=inline(
            cb_button(T.BTN_BIZ_TALK, "biz_talk"), cb_button(T.BTN_BIZ_JOIN, "biz_join")))

    @router.message(PRIVATE, F.text == T.BTN_CONSULTANT)
    async def menu_consultant(message: Message, state: FSMContext):
        await state.clear()
        await state.set_state(Ask.question)
        await message.answer(T.CONSULTANT_ASK.format(hours=hours))

    if cfg.enable_orders:
        @router.message(PRIVATE, F.text == T.BTN_ORDER)
        async def menu_order(message: Message, state: FSMContext, bot: Bot):
            await start_order(bot, message.chat.id, state)

    # 5а. Мини-аппдан келган маълумот: сават (буюртма) ёки маҳсулот ҳақида савол
    @router.message(PRIVATE, F.web_app_data)
    async def from_catalog(message: Message, state: FSMContext, bot: Bot, db: Storage, products: dict):
        await state.clear()
        remember(db, message.from_user)
        try:
            data = json.loads(message.web_app_data.data)
        except ValueError:
            log.warning("Мини-аппдан нотўғри маълумот келди")
            return
        if data.get("t") == "ask":
            item = find_product(products, str(data.get("id", "")))
            name = str(item.get("name", "")) if item else ""
            await state.set_state(Ask.question)
            await state.update_data(product=name)
            await message.answer(T.ASK_ABOUT_PRODUCT.format(product=html.escape(name), hours=hours) if name
                                 else T.CONSULTANT_ASK.format(hours=hours))
            return
        if data.get("t") != "order":
            return
        lines, total, points = [], 0, 0.0
        for entry in list(data.get("items", []))[:60]:
            try:
                product_id, qty = str(entry[0]), max(1, min(99, int(entry[1])))
            except (TypeError, ValueError, IndexError):
                continue
            item = find_product(products, product_id)
            if not item or not isinstance(item.get("price"), (int, float)):
                continue
            line_sum = int(item["price"]) * qty
            total += line_sum
            points += float(item.get("points") or 0) * qty
            lines.append(T.APP_ORDER_LINE.format(name=html.escape(str(item.get("name", ""))), qty=qty,
                                                 sum=money(line_sum)))
        if not lines:
            await message.answer(T.APP_ORDER_EMPTY, reply_markup=main_menu(cfg))
            return
        region = "region" if data.get("r") == "region" else "tashkent"
        free_from, fee = DELIVERY_RULES[region]
        delivery = 0 if total >= free_from else fee
        summary = T.APP_ORDER_SUMMARY.format(
            lines="\n".join(lines), total=money(total), points=points_text(points), region=T.REGIONS[region],
            delivery=T.APP_DELIVERY_FREE if not delivery else f"{money(delivery)} сўм", grand=money(total + delivery))
        await message.answer(summary)
        if not cfg.enable_orders:
            await notify_managers(bot, cfg, db, message.from_user.id,
                                  T.GROUP_QUESTION.format(user=describe_user(db, message.from_user)) + "\n" + summary)
            db.add_lead(message.from_user.id, "question", "каталогдан сават")
            await message.answer(T.QUESTION_SENT, reply_markup=main_menu(cfg))
            return
        delivery_text = T.APP_DELIVERY_FREE if not delivery else f"{money(delivery)} сўм"
        await state.update_data(items_html="\n".join(lines) + "\n" + T.APP_GROUP_TOTAL.format(
            grand=money(total + delivery), points=points_text(points), region=T.REGIONS[region], delivery=delivery_text))
        row = db.get_user(message.from_user.id)
        if row and row["phone"]:
            await state.set_state(Order.address)
            await message.answer(T.ORDER_ASK_ADDRESS, reply_markup=main_menu(cfg))
        else:
            await state.set_state(Order.phone)
            await message.answer(T.ORDER_ASK_PHONE, reply_markup=phone_keyboard(allow_skip=False))

    # 6. Inline тугмалар
    @router.callback_query(F.data.startswith("cat:"))
    async def show_category(call: CallbackQuery, bot: Bot, products: dict):
        await call.answer()
        parts = call.data.split(":")
        key = parts[1] if len(parts) > 1 else ""
        offset = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else 0
        if key not in T.CATEGORIES:
            return
        chat = call.from_user.id
        items = products.get(key, [])
        if offset == 0:
            header = f"<b>{T.CATEGORIES[key]}</b>"
            if key == "health":
                header += f"\n\n{T.HEALTH_NOTE}"
            await bot.send_message(chat, header)
        else:
            await drop_buttons(call)
        if not items:
            await bot.send_message(chat, T.CATEGORY_EMPTY)
            return
        for item in items[offset:offset + CHAT_CATEGORY_LIMIT]:
            price = item.get("price", "")
            caption = T.PRODUCT_CARD.format(
                name=html.escape(str(item.get("name", ""))),
                description=html.escape(str(item.get("description") or item.get("series") or "")),
                price=html.escape(f"{money(price)} сўм" if isinstance(price, (int, float)) else str(price)),
                points=html.escape(points_text(item.get("points", ""))),
            )
            keyboard = inline(
                cb_button(T.BTN_BUY_WITH_DISCOUNT, "reg"),
                # Telegram callback маълумоти 64 байтдан ошмаслиги керак
                cb_button(T.BTN_HELP_CHOOSE,
                          "ask:" + str(item.get("id", "")).encode()[:56].decode(errors="ignore")),
            )
            photo = item.get("photo")
            if photo:
                try:
                    await bot.send_photo(chat, photo, caption=caption, reply_markup=keyboard)
                    continue
                except TelegramBadRequest as exc:
                    log.warning("Расм юборилмади (%s): %s", item.get("id"), exc)
            await bot.send_message(chat, caption, reply_markup=keyboard)
        rest = len(items) - offset - CHAT_CATEGORY_LIMIT
        if rest > 0:
            await bot.send_message(
                chat, (T.CATEGORY_MORE_APP if has_webapp(cfg) else T.CATEGORY_MORE).format(count=rest),
                reply_markup=inline(cb_button(T.BTN_MORE.format(count=min(rest, CHAT_CATEGORY_LIMIT)),
                                              f"cat:{key}:{offset + CHAT_CATEGORY_LIMIT}")))

    @router.callback_query(F.data == "reg")
    async def discount_from_product(call: CallbackQuery, bot: Bot):
        await call.answer()
        await send_discount(bot, call.from_user.id)

    @router.callback_query(F.data == "registered")
    async def registered(call: CallbackQuery, state: FSMContext, bot: Bot, db: Storage):
        await call.answer()
        remember(db, call.from_user)
        first_time = db.set_registered(call.from_user.id)
        await state.set_state(Reg.phone)
        await state.update_data(first_time=first_time)
        await bot.send_message(call.from_user.id, T.REGISTERED, reply_markup=inline(
            url_button("App Store", cfg.app_store_url), url_button("Google Play", cfg.google_play_url)))
        row = db.get_user(call.from_user.id)
        if row and row["phone"]:
            await finish_registration(bot, call.from_user, state, db)
        else:
            await bot.send_message(call.from_user.id, T.ASK_PHONE, reply_markup=phone_keyboard(allow_skip=True))

    @router.callback_query(F.data.in_({"rem:1", "rem:0"}))
    async def set_reminders(call: CallbackQuery, bot: Bot, db: Storage):
        await call.answer()
        on = call.data == "rem:1"
        remember(db, call.from_user)
        db.set_reminders(call.from_user.id, on)
        await drop_buttons(call)
        await bot.send_message(call.from_user.id, T.REMINDERS_ON if on else T.REMINDERS_OFF)

    @router.callback_query(F.data.startswith("ask:"))
    async def ask_about_product(call: CallbackQuery, state: FSMContext, bot: Bot, products: dict):
        await call.answer()
        item = find_product(products, call.data[4:])
        name = str(item.get("name", "")) if item else ""
        await state.clear()
        await state.set_state(Ask.question)
        await state.update_data(product=name)
        text = (T.ASK_ABOUT_PRODUCT.format(product=html.escape(name), hours=hours) if name
                else T.CONSULTANT_ASK.format(hours=hours))
        await bot.send_message(call.from_user.id, text)

    @router.callback_query(F.data == "consult")
    async def consult_from_reminder(call: CallbackQuery, state: FSMContext, bot: Bot):
        await call.answer()
        await state.clear()
        await state.set_state(Ask.question)
        await bot.send_message(call.from_user.id, T.CONSULTANT_ASK.format(hours=hours))

    @router.callback_query(F.data == "biz_talk")
    async def biz_talk(call: CallbackQuery, state: FSMContext, bot: Bot):
        await call.answer()
        await state.clear()
        await state.set_state(BizTalk.details)
        await bot.send_message(call.from_user.id, T.BIZ_TALK_ASK)

    @router.callback_query(F.data == "biz_join")
    async def biz_join(call: CallbackQuery, bot: Bot, db: Storage):
        await call.answer()
        remember(db, call.from_user)
        db.add_lead(call.from_user.id, "business_join")
        if cfg.business_ref_link:
            await bot.send_message(call.from_user.id, T.BIZ_JOIN,
                                   reply_markup=inline(url_button(T.BTN_BIZ_REGISTER, cfg.business_ref_link)))
        else:
            log.warning("BUSINESS_REF_LINK кўрсатилмаган")
            await bot.send_message(call.from_user.id, T.BIZ_JOIN_NO_LINK)
        await notify_managers(bot, cfg, db, call.from_user.id,
                              T.GROUP_BIZ_JOIN.format(user=describe_user(db, call.from_user)))

    @router.callback_query(F.data == "order")
    async def order_from_reminder(call: CallbackQuery, state: FSMContext, bot: Bot):
        await call.answer()
        if cfg.enable_orders:
            await start_order(bot, call.from_user.id, state)

    @router.callback_query(Order.payment, F.data.startswith("pay:"))
    async def order_payment(call: CallbackQuery, state: FSMContext, bot: Bot, db: Storage):
        method = T.PAYMENTS.get(call.data[4:])
        await call.answer()
        if not method:
            return
        data = await state.get_data()
        await state.clear()
        user = call.from_user
        remember(db, user)
        items, address = data.get("items", ""), data.get("address", "")
        items_html = data.get("items_html") or html.escape(items)  # каталогдан келган тайёр рўйхат
        db.add_lead(user.id, "order", f"{items or 'каталогдан'} | {address} | {method}")
        await drop_buttons(call)
        await notify_managers(bot, cfg, db, user.id, T.GROUP_ORDER.format(
            user=describe_user(db, user), items=items_html,
            address=html.escape(address), payment=html.escape(method)))
        await bot.send_message(user.id, T.ORDER_DONE, reply_markup=main_menu(cfg))

    # 7. Бот жавоб кутаётган қадамлар
    @router.message(Reg.phone, PRIVATE, F.contact)
    async def reg_contact(message: Message, state: FSMContext, bot: Bot, db: Storage):
        db.set_phone(message.from_user.id, message.contact.phone_number)
        await finish_registration(bot, message.from_user, state, db)

    @router.message(Reg.phone, PRIVATE, F.text == T.BTN_SKIP)
    async def reg_skip(message: Message, state: FSMContext, bot: Bot, db: Storage):
        await finish_registration(bot, message.from_user, state, db)

    @router.message(Reg.phone, PRIVATE, F.text.regexp(PHONE_RE))
    async def reg_typed_phone(message: Message, state: FSMContext, bot: Bot, db: Storage):
        db.set_phone(message.from_user.id, message.text.strip())
        await finish_registration(bot, message.from_user, state, db)

    @router.message(Reg.phone, PRIVATE)
    async def reg_phone_again(message: Message):
        await message.answer(T.ASK_PHONE_AGAIN, reply_markup=phone_keyboard(allow_skip=True))

    @router.message(BizTalk.details, PRIVATE, F.text)
    async def biz_talk_done(message: Message, state: FSMContext, bot: Bot, db: Storage):
        await state.clear()
        user = message.from_user
        remember(db, user)
        text = message.text[:1000]
        db.add_lead(user.id, "business_talk", text)
        await notify_managers(bot, cfg, db, user.id, T.GROUP_BIZ_TALK.format(
            user=describe_user(db, user), text=html.escape(text)))
        await message.answer(T.BIZ_TALK_DONE, reply_markup=main_menu(cfg))

    @router.message(BizTalk.details, PRIVATE)
    async def biz_talk_text_please(message: Message):
        await message.answer(T.TEXT_PLEASE)

    @router.message(Ask.question, PRIVATE)
    async def question_in_state(message: Message, state: FSMContext, bot: Bot, db: Storage):
        data = await state.get_data()
        await state.clear()
        await relay_question(message, bot, db, data.get("product"))

    @router.message(Order.items, PRIVATE, F.text)
    async def order_items(message: Message, state: FSMContext, db: Storage):
        await state.update_data(items=message.text[:1000])
        remember(db, message.from_user)
        row = db.get_user(message.from_user.id)
        if row and row["phone"]:
            await state.set_state(Order.address)
            await message.answer(T.ORDER_ASK_ADDRESS)
        else:
            await state.set_state(Order.phone)
            await message.answer(T.ORDER_ASK_PHONE, reply_markup=phone_keyboard(allow_skip=False))

    @router.message(Order.phone, PRIVATE, F.contact)
    async def order_contact(message: Message, state: FSMContext, db: Storage):
        db.set_phone(message.from_user.id, message.contact.phone_number)
        await state.set_state(Order.address)
        await message.answer(T.ORDER_ASK_ADDRESS, reply_markup=main_menu(cfg))

    @router.message(Order.phone, PRIVATE, F.text.regexp(PHONE_RE))
    async def order_typed_phone(message: Message, state: FSMContext, db: Storage):
        db.set_phone(message.from_user.id, message.text.strip())
        await state.set_state(Order.address)
        await message.answer(T.ORDER_ASK_ADDRESS, reply_markup=main_menu(cfg))

    @router.message(Order.phone, PRIVATE)
    async def order_phone_again(message: Message):
        await message.answer(T.ASK_PHONE_AGAIN, reply_markup=phone_keyboard(allow_skip=False))

    @router.message(Order.address, PRIVATE, F.text)
    async def order_address(message: Message, state: FSMContext):
        await state.update_data(address=message.text[:500])
        await state.set_state(Order.payment)
        await message.answer(T.ORDER_ASK_PAYMENT, reply_markup=inline(
            [InlineKeyboardButton(text=title, callback_data=f"pay:{key}") for key, title in T.PAYMENTS.items()]))

    @router.message(Order.payment, PRIVATE)
    async def order_payment_again(message: Message):
        await message.answer(T.ORDER_ASK_PAYMENT, reply_markup=inline(
            [InlineKeyboardButton(text=title, callback_data=f"pay:{key}") for key, title in T.PAYMENTS.items()]))

    @router.message(StateFilter(Order.items, Order.address), PRIVATE)
    async def order_text_please(message: Message):
        await message.answer(T.TEXT_PLEASE)

    # 8. Бошқа ҳар қандай хабар — консультантга савол
    @router.message(PRIVATE, StateFilter(None))
    async def question_free(message: Message, bot: Bot, db: Storage):
        await relay_question(message, bot, db, None)

    return router


def build_dispatcher(cfg: Config, db: Storage, products: dict) -> Dispatcher:
    dp = Dispatcher()
    dp["cfg"] = cfg
    dp["db"] = db
    dp["products"] = products
    dp.include_router(build_router(cfg))
    return dp


def catalog_urls(value: str) -> list[str]:
    """MINIAPP_URL'да бир нечта манзил бўлиши мумкин (вергул ёки бўшлиқ билан ажратилади).

    Биринчи очилгани ишлатилади. Telegram мини-апп фақат https:// манзилда очилади (http://localhost — фақат синаш учун).
    """
    urls = []
    for url in re.split(r"[,\s]+", value or ""):
        local = url.startswith(("http://localhost", "http://127.0.0.1"))  # фақат компьютерда синаш учун
        if (url.startswith("https://") or local) and url not in urls:
            urls.append(url if url.endswith("/") or "?" in url else url + "/")
    return urls


async def catalog_alive(session, url: str) -> bool:
    """Каталог саҳифаси ёнидаги products.json очилиб, ичида маҳсулотлар бўлса — каталог ишлаяпти."""
    try:
        async with session.get(url.split("?", 1)[0].rstrip("/") + "/products.json") as response:
            if response.status != 200:
                return False
            data = await response.json(content_type=None)
            return bool(isinstance(data, dict) and data.get("products"))
    except Exception:  # noqa: BLE001 — тармоқ ёки JSON хатоси ҳам «очилмади» деган маъно
        return False


async def refresh_miniapp(cfg: Config, urls: list[str]) -> None:
    """Каталог очилса «Каталог» тугмаси, очилмаса чатдаги «Маҳсулотлар» кўрсатилади (манзиллар тартиб билан текширилади)."""
    import aiohttp
    found = ""
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15), trust_env=True) as session:
            for url in urls:
                if await catalog_alive(session, url):
                    found = url
                    break
    except Exception:  # noqa: BLE001
        found = ""
    if found != cfg.miniapp_url:
        cfg.miniapp_url = found
        if found:
            log.info("Каталог очилди, «Каталог» тугмаси ёқилди: %s", found)
        else:
            log.info("Каталог очилмаяпти, ҳозирча чатдаги «Маҳсулотлар» кўрсатилади")


async def watch_miniapp(cfg: Config, urls: list[str]) -> None:
    """Каталогни ҳар 5 дақиқада қайта текширади."""
    while True:
        await asyncio.sleep(300)
        await refresh_miniapp(cfg, urls)


# --- Ўзи янгиланиш: каталог сайтидаги bot.tar.gz -----------------------------

BUNDLE_NAME = "bot.tar.gz"
BUNDLE_FILES = ("bot.py", "texts.py", "storage.py", "products.json", "defaults.env")  # .env ва bot.db ҳеч қачон эмас
MAX_BUNDLE = 5 * 1024 * 1024
UPDATE_EVERY = int(os.environ.get("UPDATE_EVERY", "600") or 600)  # сония
UPDATE_DIR = BASE_DIR


def bundle_changes(data: bytes, base: Path) -> dict[str, bytes] | None:
    """Архивдаги файллардан ҳозиргисидан фарқ қиладиганлари. Архив бузуқ ёки код хато бўлса — None."""
    if not data or len(data) > MAX_BUNDLE:
        return None
    files: dict[str, bytes] = {}
    try:
        with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as archive:
            for member in archive.getmembers():
                if member.isfile() and member.name in BUNDLE_FILES:
                    files[member.name] = archive.extractfile(member).read()
    except (tarfile.TarError, OSError, EOFError):
        return None
    if "bot.py" not in files:
        return None
    try:
        for name, content in files.items():
            if name.endswith(".py"):
                compile(content, name, "exec")
        if "products.json" in files:
            catalog = json.loads(files["products.json"])
            if not (isinstance(catalog, dict) and catalog.get("products")):
                return None
    except (SyntaxError, ValueError):
        return None
    return {name: content for name, content in files.items()
            if not (base / name).exists() or (base / name).read_bytes() != content}


def apply_update(changes: dict[str, bytes], base: Path) -> None:
    for name, content in changes.items():
        temp = base / (name + ".new")
        temp.write_bytes(content)
        os.replace(temp, base / name)


async def fetch_bundle(urls: list[str]) -> bytes | None:
    import aiohttp
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=30), trust_env=True) as session:
        for url in urls:
            try:
                async with session.get(url.split("?", 1)[0].rstrip("/") + "/" + BUNDLE_NAME) as response:
                    if response.status == 200:
                        data = await response.read()
                        if 0 < len(data) <= MAX_BUNDLE:
                            return data
            except Exception:  # noqa: BLE001 — кейинги манзилни синаймиз
                continue
    return None


async def check_update_once(cfg: Config, urls: list[str], base: Path) -> list[str]:
    """Сайтда янги версия бўлса, файлларни алмаштиради ва ўзгарган файллар рўйхатини қайтаради."""
    order = ([cfg.miniapp_url] if cfg.miniapp_url else []) + [url for url in urls if url != cfg.miniapp_url]
    data = await fetch_bundle(order)
    changes = bundle_changes(data, base) if data else None
    if not changes:
        return []
    apply_update(changes, base)
    return sorted(changes)


async def watch_updates(cfg: Config, urls: list[str], dp: Dispatcher, restart: dict) -> None:
    """Ҳар 10 дақиқада текширади; янги версия ўрнатилса, ботни тўхтатиб, қайта ишга туширишни сўрайди."""
    while True:
        await asyncio.sleep(UPDATE_EVERY)
        try:
            changed = await check_update_once(cfg, urls, UPDATE_DIR)
        except Exception as exc:  # noqa: BLE001 — янгиланиш бўлмаса ҳам бот ишлайверади
            log.warning("Янгиланишни текшириб бўлмади: %s", exc)
            continue
        if changed:
            log.info("Янги версия ўрнатилди (%s): бот қайта ишга тушяпти", ", ".join(changed))
            restart["now"] = True
            await dp.stop_polling()
            return


async def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    cfg = load_config()
    if not cfg.bot_token:
        raise SystemExit("BOT_TOKEN кўрсатилмаган: .env файлини тўлдиринг (README.md га қаранг).")
    if not cfg.managers_chat_id:
        log.warning("MANAGERS_CHAT_ID кўрсатилмаган: аризалар группага бормайди. "
                    "Группада «/setgroup КОД» (КОД — .env даги SETUP_CODE) деб ёзинг.")
    db = Storage(cfg.db_path)
    products = load_products()
    session = None
    if os.environ.get("TELEGRAM_API_URL"):  # ўз Bot API серверингиз (ёки синов сервери) бўлса
        from aiogram.client.session.aiohttp import AiohttpSession
        from aiogram.client.telegram import TelegramAPIServer
        session = AiohttpSession(api=TelegramAPIServer.from_base(os.environ["TELEGRAM_API_URL"]))
    bot = Bot(cfg.bot_token, session=session, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = build_dispatcher(cfg, db, products)
    await bot.set_my_commands([BotCommand(command="start", description=T.CMD_START)],
                              scope=BotCommandScopeAllPrivateChats())
    await bot.delete_webhook()
    try:  # бошқа жойда (масалан, эски Colab'да) шу бот ишлаб турганини аниқлаш
        await bot.get_updates(limit=1, timeout=0)
    except TelegramConflictError:
        log.warning("ДИҚҚАТ: бу бот бошқа жойда ҳам ишлаяпти (масалан, эски Colab). Иккита нусха бирга "
                    "ишласа, хабарлар аралашиб кетади — эскисини тўхтатинг.")
    urls, cfg.miniapp_url = catalog_urls(cfg.miniapp_url), ""
    tasks, restart = [], {"now": False}
    if urls:  # биринчи /start'дан олдин текшириб олинади, кейин ҳар 5 дақиқада
        await refresh_miniapp(cfg, urls)
        if not cfg.miniapp_url:
            log.info("Каталог ҳозирча очилмаяпти: чатдаги «Маҳсулотлар» кўрсатилади, ҳар 5 дақиқада қайта текширилади")
        tasks.append(asyncio.create_task(watch_miniapp(cfg, urls)))
        if cfg.auto_update:
            tasks.append(asyncio.create_task(watch_updates(cfg, urls, dp, restart)))
    log.info("Бот ишга тушди")
    try:
        await dp.start_polling(bot)
    finally:
        for task in tasks:
            task.cancel()
    if restart["now"]:  # янги код билан ўша жараёнда қайта бошлаймиз (Colab катакчаси тўхтамайди)
        os.execv(sys.executable, [sys.executable, str(Path(__file__).resolve()), *sys.argv[1:]])


if __name__ == "__main__":
    asyncio.run(main())
