# -*- coding: utf-8 -*-
"""SQLite база: фойдаланувчилар, аризалар ва менежер жавоблари учун боғлам."""
import sqlite3
from datetime import datetime, timedelta, timezone

TASHKENT = timezone(timedelta(hours=5))

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    user_id     INTEGER PRIMARY KEY,
    first_name  TEXT,
    username    TEXT,
    source      TEXT,
    phone       TEXT,
    registered  INTEGER NOT NULL DEFAULT 0,
    reminders   INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS leads (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL,
    kind        TEXT NOT NULL,  -- register | business_talk | business_join | order | question
    details     TEXT,
    created_at  TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS relay (
    group_message_id INTEGER PRIMARY KEY,
    user_id          INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT
);
"""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class Storage:
    def __init__(self, path: str):
        self.conn = sqlite3.connect(path)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self.conn.execute("INSERT OR IGNORE INTO meta (key, value) VALUES ('started_at', ?)", (_now(),))
        self.conn.commit()

    def started_at(self) -> str:
        """Ҳисоб қачон бошланган (база яратилган вақт, UTC)."""
        row = self.conn.execute("SELECT value FROM meta WHERE key = 'started_at'").fetchone()
        return row["value"] if row else _now()

    def totals(self, now: datetime | None = None) -> dict:
        """Умумий: нечта одам келди (бугун, 7 кунда), рўйхат, буюртма, бизнес, савол."""
        now = now or datetime.now(timezone.utc)
        day = now.astimezone(TASHKENT).replace(hour=0, minute=0, second=0, microsecond=0)
        day_start = day.astimezone(timezone.utc).isoformat(timespec="seconds")
        week_start = (now - timedelta(days=7)).astimezone(timezone.utc).isoformat(timespec="seconds")
        row = self.conn.execute(
            "SELECT COUNT(*) AS users, SUM(created_at >= ?) AS today, SUM(created_at >= ?) AS week, "
            "SUM(registered) AS registered FROM users", (day_start, week_start)).fetchone()
        kinds = {kind: count for kind, count in
                 self.conn.execute("SELECT kind, COUNT(*) FROM leads GROUP BY kind").fetchall()}
        return {
            "users": row["users"], "today": row["today"] or 0, "week": row["week"] or 0,
            "registered": row["registered"] or 0, "orders": kinds.get("order", 0),
            "business": kinds.get("business_talk", 0) + kinds.get("business_join", 0),
            "questions": kinds.get("question", 0),
        }

    # --- фойдаланувчилар ---
    def touch_user(self, user_id: int, first_name: str, username: str | None, source: str | None) -> None:
        """Фойдаланувчини қўшади ёки янгилайди. Манба фақат биринчи марта ёзилади."""
        self.conn.execute(
            "INSERT INTO users (user_id, first_name, username, source, created_at) "
            "VALUES (?, ?, ?, ?, ?) "
            "ON CONFLICT(user_id) DO UPDATE SET first_name = excluded.first_name, "
            "username = excluded.username, source = COALESCE(users.source, excluded.source)",
            (user_id, first_name, username, source, _now()),
        )
        self.conn.commit()

    def get_user(self, user_id: int) -> sqlite3.Row | None:
        return self.conn.execute("SELECT * FROM users WHERE user_id = ?", (user_id,)).fetchone()

    def set_phone(self, user_id: int, phone: str) -> None:
        self.conn.execute("UPDATE users SET phone = ? WHERE user_id = ?", (phone, user_id))
        self.conn.commit()

    def set_registered(self, user_id: int) -> bool:
        """Рўйхатдан ўтди деб белгилайди. Олдин белгиланмаган бўлса True қайтаради."""
        cur = self.conn.execute(
            "UPDATE users SET registered = 1 WHERE user_id = ? AND registered = 0", (user_id,)
        )
        self.conn.commit()
        return cur.rowcount > 0

    def set_reminders(self, user_id: int, on: bool) -> None:
        self.conn.execute("UPDATE users SET reminders = ? WHERE user_id = ?", (1 if on else 0, user_id))
        self.conn.commit()

    def reminder_recipients(self) -> list[int]:
        rows = self.conn.execute("SELECT user_id FROM users WHERE reminders = 1").fetchall()
        return [row["user_id"] for row in rows]

    # --- аризалар ---
    def add_lead(self, user_id: int, kind: str, details: str = "") -> None:
        self.conn.execute(
            "INSERT INTO leads (user_id, kind, details, created_at) VALUES (?, ?, ?, ?)",
            (user_id, kind, details, _now()),
        )
        self.conn.commit()

    # --- менежер жавоблари ---
    def save_relay(self, group_message_id: int, user_id: int) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO relay (group_message_id, user_id) VALUES (?, ?)",
            (group_message_id, user_id),
        )
        self.conn.commit()

    def relay_user(self, group_message_id: int) -> int | None:
        row = self.conn.execute(
            "SELECT user_id FROM relay WHERE group_message_id = ?", (group_message_id,)
        ).fetchone()
        return row["user_id"] if row else None

    # --- статистика ---
    def stats(self) -> list[sqlite3.Row]:
        """Манба бўйича: нечта одам келди, рўйхатдан ўтди, буюртма, бизнес, савол."""
        return self.conn.execute(
            """
            SELECT u.source AS source,
                   COUNT(*) AS users,
                   SUM(u.registered) AS registered,
                   SUM((SELECT COUNT(*) FROM leads l
                        WHERE l.user_id = u.user_id AND l.kind = 'order')) AS orders,
                   SUM((SELECT COUNT(*) FROM leads l
                        WHERE l.user_id = u.user_id
                          AND l.kind IN ('business_talk', 'business_join'))) AS business,
                   SUM((SELECT COUNT(*) FROM leads l
                        WHERE l.user_id = u.user_id AND l.kind = 'question')) AS questions
            FROM users u
            GROUP BY u.source
            ORDER BY users DESC
            """
        ).fetchall()
